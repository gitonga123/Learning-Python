{
    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",
    'name': 'Bootswatch Darkly',
    'summary': 'Bootswatch Darkly',
    'description': 'Bootswatch Darkly',
    'category': 'Theme',
    'version': '0.3',
    'images': ['images/darkly-thumbnail.png'],
    'depends': ['website'],
    'data': ['views/bootswatch-darkly.xml'],
    'application': False,
}
